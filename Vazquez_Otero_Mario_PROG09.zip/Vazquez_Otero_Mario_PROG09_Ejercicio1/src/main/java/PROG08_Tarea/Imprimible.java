package PROG08_Tarea;

/**
 *
 * @author Mario
 */
public interface Imprimible {
        
    /**Interfaz para devolver String
     * @return
     */
    String devolverInfoString(); 
        
}
